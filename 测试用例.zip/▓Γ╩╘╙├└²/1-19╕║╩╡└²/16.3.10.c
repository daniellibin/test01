/*
From:ITC
16
Macros defects
16.3
Controlling macro checking
16.3.10
 Macros should not be redefined
*/
#define A1
#undef A
#define A2

