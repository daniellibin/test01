/*
From:ITC
16
Macros defects
16.3
Controlling macro checking
16.3.9
"Header guards should be followed by according ""#define"" macro"
*/
#ifndef MYFILE_H
#define MYFILE_H 
	  //...
#endif
