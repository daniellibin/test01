/*
From:ITC
16
Macros defects
16.3
Controlling macro checking
16.3.8
Macros name should comply with a naming convention
*/
#define Foo
