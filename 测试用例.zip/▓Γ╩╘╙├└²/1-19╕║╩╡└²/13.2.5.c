/*
From:ITC
13
"API defects
"
13.2
Memset function
13.2.5
parameter order is wrong
*/
#include <stdio.h>
#include<memory.h>
void memset_function_005() {
	int a[5] = { 1,2,3,4,5 };
	int i;
	memset(a,0,5 * sizeof(int));  /*Tool should Not detect this line as error*/ /*ERROR:API error*/
	for (i = 0; i < 3; i++) {
		printf("%d ", a[i]);
	}
}
