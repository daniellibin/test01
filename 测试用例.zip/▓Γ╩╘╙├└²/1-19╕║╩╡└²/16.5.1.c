/*
From:ITC
16
Macros defects
16.5
Using iterators
16.5.1
Macro use iterator
*/
#define list<int> list_int

