/*
From:ITC
16
Macros defects
16.1
Constant macros
16.1.1
Constant not defined
*/
#include<stdio.h>                                                                                                                        #define PI 3.14     /*Tool should Not detect this line as error*/ /*ERROR:Macros error*/       
float constant_macros_001() {
	float r;
	printf("����Բ�İ뾶��");
	scanf("%f", &r);
	float area;
	area = PI * r * r;

}
